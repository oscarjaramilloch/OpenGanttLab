# OpenGanttLab — Brand Identity & UI Implementation

## 1. Objetivo

Implementar una identidad visual profesional para **OpenGanttLab**, una aplicación SaaS especializada en visualización, comparación y presentación de cronogramas de proyectos.

La identidad debe transmitir planificación, tiempo, control, precisión, progreso, comparación de escenarios, visualización de información, software empresarial, ingeniería y Project Controls.

**No rediseñar la funcionalidad de la aplicación.** El objetivo principal es aplicar una identidad visual coherente y elevar la calidad de la interfaz existente.

## 2. Dirección creativa aprobada

### Concepto 02 — Cronograma en movimiento

El concepto parte de una representación abstracta de un cronograma Gantt:

- Tres barras horizontales de diferente longitud.
- Una línea vertical que representa un hito o eje temporal.
- Un diamante que representa un milestone.
- Una composición equilibrada, geométrica y fácilmente reconocible.

### Simbolismo

| Elemento | Significado |
|---|---|
| Barras | Actividades, duración y planificación |
| Diferentes longitudes | Escala temporal y diversidad de tareas |
| Línea vertical | Punto de control, fecha de corte o hito |
| Diamante | Milestone, evento importante o decisión |
| Composición horizontal | Flujo del tiempo y avance del proyecto |

### Tagline principal

> From plans to progress.

Alternativas: `Plan. Compare. Present.`, `Clarity across every timeline.`, `From schedules to decisions.`, `Plan with precision.`, `See the plan. Shape the outcome.`

## 3. Regla fundamental de color

### NO USAR DEGRADADOS

La identidad debe utilizar colores planos, rellenos sólidos, bordes limpios y contraste controlado. Las sombras, si se usan en la interfaz, deben ser muy sutiles.

Prohibido:

- Gradientes lineales o radiales.
- Efectos glossy, 3D, metálicos o resplandores.
- Mezclas de azul a verde o naranja a amarillo.
- Sombras excesivas.
- Saturación excesiva en toda la interfaz.

La marca debe reconocerse por su geometría y composición, no por efectos visuales.

## 4. Paleta oficial propuesta

| Nombre | Hex | Uso |
|---|---|---|
| Navy / Structure | `#0F2D5B` | Logotipo, texto principal, navegación y estructura |
| Planning Blue | `#2563EB` | Planificación, barras principales y acciones primarias |
| Progress Green | `#16A34A` | Avance, progreso y estados positivos |
| Milestone Orange | `#F59E0B` | Hitos, atención y puntos importantes |
| Support Gray | `#E5E7EB` | Fondos, divisores y elementos secundarios |

### Colores auxiliares de aplicación

| Nombre | Hex | Uso |
|---|---|---|
| Background | `#F8FAFC` | Fondo general |
| Surface | `#FFFFFF` | Tarjetas, paneles y modales |
| Surface Secondary | `#F1F5F9` | Fondos secundarios |
| Border | `#E2E8F0` | Bordes y divisores |
| Text Primary | `#0F172A` | Texto principal |
| Text Secondary | `#64748B` | Texto secundario |
| Text Muted | `#94A3B8` | Metadatos y ayudas |
| Dark Background | `#081A33` | Fondo de modo oscuro |
| Dark Surface | `#0F2D5B` | Superficies en modo oscuro |

### Proporción cromática

- 70–80 %: neutros, blancos y superficies.
- 10–15 %: navy y azul.
- 5–10 %: verde y naranja como acentos funcionales.

El naranja y el verde no deben convertirse en colores decorativos omnipresentes. Cada uno debe tener un significado.

## 5. Sistema semántico de color para el Gantt

| Elemento | Color |
|---|---|
| Actividad planificada | `#2563EB` |
| Actividad ejecutada / progreso | `#16A34A` |
| Hito / milestone | `#F59E0B` |
| Línea de fecha de corte | `#0F2D5B` |
| Dependencia / conector | `#94A3B8` |
| Actividad seleccionada | Azul con borde navy |
| Actividad crítica | Naranja o rojo semántico, según lógica existente |
| Actividad completada | Verde |
| Actividad futura | Azul |
| Actividad retrasada | Naranja / rojo semántico |

No forzar estos colores si la aplicación ya tiene una lógica de estados. Integrar el sistema de marca con los estados existentes.

## 6. Construcción del isotipo

El isotipo se basa en tres barras Gantt, una línea vertical y un diamante.

Reglas:

- Tres barras horizontales de diferente longitud.
- Alineación visual consistente.
- Línea vertical fina.
- Diamante sólido.
- Esquinas ligeramente redondeadas en las barras.
- Sin perspectiva, volumen, degradados ni contornos innecesarios.
- Sin calendarios literales, relojes o flechas genéricas de crecimiento.
- Trabajar proporciones y espacio negativo para evitar la apariencia de clipart.

Tratamiento cromático principal:

- Barra superior: `#2563EB`.
- Barra intermedia: `#16A34A`.
- Barra inferior: `#F59E0B`.
- Línea vertical: `#0F2D5B`.
- Diamante: `#0F2D5B`.

Evaluar también una variante con diamante naranja y línea navy.

## 7. Wordmark

Nombre oficial: **OPEN GANTT LAB**.

Características:

- Sans-serif moderna.
- Peso semibold o bold.
- Mayúsculas.
- Espaciado controlado.
- Alta legibilidad.
- Apariencia técnica y corporativa.

Tratamiento principal:

- `OPEN` → Navy `#0F2D5B`.
- `GANTT` → Planning Blue `#2563EB`.
- `LAB` → Navy `#0F2D5B`.

Alternativa sobria: todo el wordmark en navy y el isotipo conserva sus colores.

## 8. Tipografía

Prioridad:

1. Inter
2. Manrope
3. Plus Jakarta Sans
4. Segoe UI como fallback empresarial

```css
font-family: "Inter", "Segoe UI", Arial, sans-serif;
```

Títulos: semibold/bold. Interfaz y datos: regular/medium. Evitar tipografías futuristas o excesivamente decorativas.

## 9. Versiones requeridas

- Horizontal: isotipo + OPEN GANTT LAB.
- Vertical: isotipo sobre el wordmark.
- Solo isotipo.
- Favicon: 16, 32, 48, 180 y 512 px.
- Modo oscuro: wordmark claro sobre `#081A33`.
- Monocromática: negro sobre blanco y blanco sobre navy.

El isotipo debe ser reconocible a 16–32 px.

## 10. Aplicación en la interfaz

La interfaz debe sentirse precisa, estructurada, clara, técnica y premium. Evitar apariencia de dashboard genérico, plantilla administrativa, sistema saturado o producto infantil.

### Navegación

- Sidebar sobrio.
- Iconos lineales consistentes.
- Azul como color de selección.
- Verde y naranja reservados para indicadores funcionales.
- Logo expandido y versión colapsada.

### Tarjetas y paneles

- Superficie blanca.
- Bordes sutiles.
- Radio moderado de 8–12 px.
- Sombras muy discretas.
- Datos protagonistas.
- No usar los cuatro colores en cada tarjeta.

### Gantt

- Fondo neutro.
- Grilla temporal discreta.
- Barras de color sólido.
- Hitos visibles.
- Dependencias con líneas finas.
- Fecha de corte con línea vertical navy.
- Selección mediante borde o fondo sutil, no glow.

### Comparación de escenarios

- Escenario principal: azul.
- Escenario alternativo: verde o naranja según la lógica.
- Diferencias mediante color, etiquetas, patrones o estilos de línea.
- No depender exclusivamente del color.

## 11. Design tokens

Usar un sistema centralizado. Si el proyecto ya posee tokens, adaptarlos en lugar de duplicarlos.

```css
:root {
  --ogl-navy: #0F2D5B;
  --ogl-blue: #2563EB;
  --ogl-green: #16A34A;
  --ogl-orange: #F59E0B;
  --ogl-gray: #E5E7EB;

  --ogl-bg: #F8FAFC;
  --ogl-surface: #FFFFFF;
  --ogl-surface-secondary: #F1F5F9;
  --ogl-border: #E2E8F0;

  --ogl-text-primary: #0F172A;
  --ogl-text-secondary: #64748B;
  --ogl-text-muted: #94A3B8;

  --ogl-dark-bg: #081A33;
  --ogl-dark-surface: #0F2D5B;

  --ogl-radius-sm: 6px;
  --ogl-radius-md: 8px;
  --ogl-radius-lg: 12px;

  --ogl-shadow-sm: 0 1px 2px rgba(15, 45, 91, 0.05);
  --ogl-shadow-md: 0 4px 12px rgba(15, 45, 91, 0.08);
}
```

## 12. Estructura de archivos recomendada

```text
/branding
  /logo
    ogl-logo-horizontal.svg
    ogl-logo-horizontal-dark.svg
    ogl-logo-vertical.svg
    ogl-logo-vertical-dark.svg
    ogl-isotype.svg
    ogl-isotype-dark.svg
    ogl-logo-monochrome.svg
    ogl-logo-white.svg
  /favicon
    favicon.svg
    favicon-32.png
    favicon-180.png
    favicon-512.png
  /brand
    colors.css
    brand-tokens.css
    BRAND_GUIDELINES.md
```

Preferir SVG para el logotipo principal.

## 13. Reglas para Claude Code

Antes de modificar el código:

1. Analizar la estructura actual del proyecto.
2. Identificar framework y sistema de estilos.
3. Identificar layout principal, navegación y temas.
4. Identificar componentes Gantt, botones, tarjetas, tablas y modales.
5. Identificar tokens existentes.
6. Evitar duplicar estilos.

Después:

- Implementar el branding de forma centralizada.
- No modificar la lógica de negocio.
- No eliminar funcionalidades.
- No cambiar estructuras de datos.
- No alterar cálculos, filtros, importaciones, exportaciones ni comportamiento del Gantt.
- No reemplazar componentes funcionales por mockups.

## 14. Criterios de aceptación

- [ ] Logo basado en barras Gantt + hito.
- [ ] No existen degradados en el sistema de marca.
- [ ] Paleta centralizada.
- [ ] Azul como color principal de planificación.
- [ ] Verde con función semántica de progreso.
- [ ] Naranja con función semántica de hitos/atención.
- [ ] Navy como estructura y contraste.
- [ ] Logo funcional en fondos claro y oscuro.
- [ ] Versiones expandida y colapsada.
- [ ] Favicon legible a 32×32.
- [ ] Gantt legible y no saturado.
- [ ] Identidad consistente en todas las pantallas.
- [ ] Ninguna funcionalidad existente se rompe.

## 15. Instrucción final

Implementa esta identidad visual como un sistema de diseño coherente, no como una colección de cambios aislados.

El concepto aprobado es **Cronograma en movimiento**: barras Gantt geométricas, una línea temporal y un hito.

La prioridad es lograr una marca distintiva mediante geometría, proporción, tipografía, espacio y uso inteligente del color, no mediante degradados ni efectos decorativos.

Si algún elemento del diseño actual entra en conflicto con esta identidad, propón una mejora visual, pero conserva siempre la funcionalidad existente.

Revisa la aplicación completa en desktop y responsive, incluyendo modo claro, modo oscuro, navegación, Gantt, tablas, formularios, modales, exportaciones y favicon.
